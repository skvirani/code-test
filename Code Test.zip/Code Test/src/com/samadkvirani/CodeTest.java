package com.samadkvirani;

import java.util.HashMap;

public class CodeTest {

    public String helloWorld(String s) {
        return s;
    }

    public String getSchedule(String courses) {
        String[] lines = courses.split("\n");
        int courseSize = Integer.parseInt(lines[0]);
        StringBuilder schedule = new StringBuilder(courseSize);
        HashMap<String, String> map = new HashMap<>();
        for(int i = 1; i < lines.length; i++) {
            String[] course = lines[i].split(" ");
            String courseName = course[0];
            for (int j = 1; j < course.length; j ++) {
                if(map.get(courseName) != null) {
                    map.put(courseName, map.get(courseName) + " " + course[j]);
                } else {
                    map.put(courseName, course[j]);
                }

            }
        }

        while (schedule.length() < courseSize * 2) {
            for (int i = 0; i < courseSize; i++) {
                if (map.containsKey(String.valueOf(i))) {
                    //if map course has prereq that is in schedule, add course
//                if (map.values().contains(schedule.toString().strip())) {
//                    map.
//
//                }
                    //if map course has prereq not in schedule, add prereq
                    if (!schedule.toString().contains(map.get(String.valueOf(i)))) {
                        schedule.append(map.get(String.valueOf(i)) + " ");
                    }
                }
                //if course is not in keys of map, add to schedule because it doesn't have prereqs
                else {
                    schedule.append(i + " ");
                }
            }

            /*if (!map.containsKey(String.valueOf(i)) && schedule.indexOf(String.valueOf(i)) == -1) {
                schedule.append(i + " ");
            } else if (schedule.toString().contains(map.get(String.valueOf(i)))) {
                schedule.append(i + " ");
            }*/
        }

        schedule.replace(schedule.length() -1, schedule.length(), "");
        return schedule.toString();

    }

}
