package com.samadkvirani;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CodeTestTest {

    CodeTest codeTest = new CodeTest();

    @Test
    public void helloWorldTest() {
        String s = "Hello world";

        String result = codeTest.helloWorld(s);

        assertEquals("Hello world", result);


    }

    @Test
    public void fourCoursesTest() {
        String courses = "4\n1 0\n2 0\n3 1 2";

        String result = codeTest.getSchedule(courses);

        assertEquals("0 1 2 3", result);
    }

    @Test
    public void sevenCoursesTest() {
        String courses = "7\n0 1 2\n1 3\n2 3\n3 4 5\n4 6\n5 6";

        String result = codeTest.getSchedule(courses);

        assertEquals("6 4 5 3 1 2 0", result);
    }

}